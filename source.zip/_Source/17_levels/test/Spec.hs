{-# OPTIONS_GHC -F -pgmF hspec-discover #-}
{-# LANGUAGE NoImplicitPrelude #-}

