{-# LANGUAGE NoImplicitPrelude #-}

module Main where

import           Protolude 
  
import qualified GameEngine as GE

main :: IO ()
main = GE.runGame


